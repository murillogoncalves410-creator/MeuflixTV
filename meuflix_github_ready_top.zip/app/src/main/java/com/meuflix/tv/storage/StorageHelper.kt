package com.meuflix.tv.storage
import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.meuflix.tv.models.Channel

object StorageHelper {
    private const val PREF = "meuflix_prefs"
    private const val KEY = "channels_v1"
    fun loadChannels(ctx: Context): MutableList<Channel> {
        val sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val json = sp.getString(KEY, null) ?: return mutableListOf()
        val type = object: TypeToken<MutableList<Channel>>(){}.type
        return Gson().fromJson(json, type)
    }
    fun saveChannels(ctx: Context, list: List<Channel>) {
        val sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val json = Gson().toJson(list)
        sp.edit().putString(KEY, json).apply()
    }
}
