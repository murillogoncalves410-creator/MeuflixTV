package com.meuflix.tv.models

data class Channel(var id:String="", var title:String="", var category:String="", var url:String="", var img:String="")
