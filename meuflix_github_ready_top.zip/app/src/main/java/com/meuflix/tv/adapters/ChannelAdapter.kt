package com.meuflix.tv.adapters
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.meuflix.tv.PlayerActivity
import com.meuflix.tv.R
import com.meuflix.tv.models.Channel

class ChannelAdapter(private val ctx: Context, private var list: MutableList<Channel>)
    : RecyclerView.Adapter<ChannelAdapter.VH>() {

    inner class VH(v: View): RecyclerView.ViewHolder(v) {
        val img: ImageView = v.findViewById(R.id.imgThumb)
        val title: TextView = v.findViewById(R.id.tvTitle)
        val cat: TextView = v.findViewById(R.id.tvCategory)
        val btn: Button = v.findViewById(R.id.btnPlay)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val c = list[position]
        holder.title.text = c.title
        holder.cat.text = c.category
        holder.img.setImageResource(android.R.drawable.ic_menu_report_image)
        holder.btn.setOnClickListener {
            val i = Intent(ctx, PlayerActivity::class.java)
            i.putExtra("url", c.url)
            i.putExtra("title", c.title)
            ctx.startActivity(i)
        }
    }

    override fun getItemCount(): Int = list.size
    fun update(newList: MutableList<Channel>) { list = newList; notifyDataSetChanged() }
}
