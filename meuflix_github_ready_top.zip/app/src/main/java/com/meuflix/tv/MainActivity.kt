package com.meuflix.tv

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.meuflix.tv.adapters.ChannelAdapter
import com.meuflix.tv.models.Channel
import com.meuflix.tv.storage.StorageHelper
import com.meuflix.tv.databinding.ActivityMainBinding
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ChannelAdapter
    private var channels = mutableListOf<Channel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        channels = StorageHelper.loadChannels(this)
        if (channels.isEmpty()) {
            channels.addAll(getDefaultChannels())
            StorageHelper.saveChannels(this, channels)
        }

        adapter = ChannelAdapter(this, channels)
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        binding.fabAdd.setOnClickListener { showAddDialog() }

        binding.searchView.setOnQueryTextListener(object: androidx.appcompat.widget.SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(query: String?): Boolean { return false }
            override fun onQueryTextChange(newText: String?): Boolean {
                val q = newText?.lowercase(Locale.getDefault()) ?: ""
                val filtered = channels.filter { it.title.lowercase().contains(q) || it.category.lowercase().contains(q) }
                adapter.update(filtered.toMutableList())
                return true
            }
        })
    }

    private fun showAddDialog() {
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_add_channel, null)
        val etTitle = v.findViewById<EditText>(R.id.etTitle)
        val etUrl = v.findViewById<EditText>(R.id.etUrl)
        val etCat = v.findViewById<EditText>(R.id.etCat)
        AlertDialog.Builder(this)
            .setTitle("Adicionar canal")
            .setView(v)
            .setPositiveButton("Salvar") { _, _ ->
                val c = Channel(id = UUID.randomUUID().toString(), title = etTitle.text.toString(),
                    url = etUrl.text.toString(), category = etCat.text.toString(), img = "")
                channels.add(0, c)
                StorageHelper.saveChannels(this, channels)
                adapter.update(channels)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun getDefaultChannels(): List<Channel> {
        return listOf(
            Channel(id="tvbrasil", title="TV Brasil", category="Brasil", url="https://streaming.cdn.ebc.com.br/tvbrasil/playlist.m3u8", img=""),
            Channel(id="france24", title="France24 (EN)", category="Notícias", url="https://static.france24.com/live/F24_EN_LO_HLS/live_web.m3u8", img=""),
            Channel(id="sintel", title="Sintel (filme)", category="Filme", url="https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8", img="")
        )
    }
}
