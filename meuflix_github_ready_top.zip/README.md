# MeuflixTV - GitHub Ready (Top Package)
This repository is prepared to build an Android debug APK using GitHub Actions.
Steps to use on mobile:
1. In your GitHub repo page, click Add file → Upload files and upload all files from this ZIP to repository root.
2. Commit to main branch.
3. Go to Actions tab → open 'Build Debug APK' run → after success download artifact 'meuflix-debug-apk'.
4. Download APK on your phone and install (allow unknown sources).
Edit channels: edit app/src/main/assets/canais.json and filmes.json on GitHub and commit; Action will rebuild.
