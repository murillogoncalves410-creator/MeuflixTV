
const defaultDB = {
  channels: [
    {name: "Canal Exemplo", url: "", image: "assets/imagens/banner.jpg"}
  ],
  films: [
    {title: "Filme Exemplo", desc: "Descrição do exemplo", url: "", poster: "assets/imagens/banner.jpg"}
  ]
};

function $(q) { return document.querySelector(q) }
function $all(q){return document.querySelectorAll(q)}

let db = loadDB();

function loadDB(){
  try{
    const raw = localStorage.getItem('meuflix_db');
    if(raw) return JSON.parse(raw);
  }catch(e){}
  localStorage.setItem('meuflix_db', JSON.stringify(defaultDB));
  return JSON.parse(JSON.stringify(defaultDB));
}

function saveDB(){
  localStorage.setItem('meuflix_db', JSON.stringify(db));
  renderCurrentList();
}

// UI actions
const lists = $('#lists');
const playerModal = $('#player-modal');
const adminModal = $('#admin-modal');
const player = $('#player');
const playerTitle = $('#player-title');

function renderCards(mode='films', filter=''){
  lists.innerHTML = '';
  const items = mode==='channels' ? db.channels : db.films;
  items.filter(i=>JSON.stringify(i).toLowerCase().includes(filter.toLowerCase()))
  .forEach(it=>{
    const div = document.createElement('div');
    div.className='card';
    const img = document.createElement('img'); img.src = it.image || it.poster || 'assets/imagens/banner.jpg';
    const h = document.createElement('h4'); h.textContent = it.name || it.title;
    const p = document.createElement('p'); p.textContent = it.desc || '';
    div.appendChild(img); div.appendChild(h); div.appendChild(p);
    div.addEventListener('click', ()=> openPlayer(it));
    lists.appendChild(div);
  });
}

function openPlayer(item){
  player.pause();
  player.removeAttribute('src');
  if(item.url && item.url.endsWith('.m3u8') && Hls.isSupported()){
    const hls = new Hls();
    hls.loadSource(item.url);
    hls.attachMedia(player);
  } else if(item.url){
    player.src = item.url;
  } else {
    alert('Sem URL de reprodução configurada.');
    return;
  }
  playerTitle.textContent = item.title || item.name || '';
  playerModal.classList.remove('hidden');
}

$('#close-player').addEventListener('click', ()=>{ playerModal.classList.add('hidden'); player.pause() });

$('#show-channels').addEventListener('click', ()=> renderCards('channels', $('#search').value));
$('#show-films').addEventListener('click', ()=> renderCards('films', $('#search').value));
$('#search').addEventListener('input', ()=> {
  const mode = document.querySelector('#show-channels.active') ? 'channels' : 'films';
  renderCards(mode, $('#search').value);
});

// Admin
$('#btn-admin').addEventListener('click', ()=>{
  const pass = prompt('Senha admin: (padrão: 1234)');
  if(pass==='1234') adminModal.classList.remove('hidden');
  else alert('Senha incorreta');
});
$('#close-admin').addEventListener('click', ()=> adminModal.classList.add('hidden'));

$('#tab-add-channel').addEventListener('click', ()=> { toggleAdminForm('channel') });
$('#tab-add-film').addEventListener('click', ()=> { toggleAdminForm('film') });
$('#tab-import').addEventListener('click', ()=> { toggleAdminForm('import') });

function toggleAdminForm(which){
  $('#form-channel').classList.toggle('hidden', which!=='channel');
  $('#form-film').classList.toggle('hidden', which!=='film');
  $('#import-export').classList.toggle('hidden', which!=='import');
}

$('#form-channel').addEventListener('submit', (e)=>{
  e.preventDefault();
  const form = e.target;
  const name = form.name.value.trim();
  const url = form.url.value.trim();
  const image = form.image.value.trim();
  db.channels.push({name,url,image});
  saveDB();
  alert('Canal salvo');
  form.reset();
});

$('#form-film').addEventListener('submit', (e)=>{
  e.preventDefault();
  const form = e.target;
  const title = form.title.value.trim();
  const desc = form.desc.value.trim();
  const url = form.url.value.trim();
  const poster = form.poster.value.trim();
  db.films.push({title,desc,url,poster});
  saveDB();
  alert('Filme salvo');
  form.reset();
});

function renderCurrentList(){
  const c = $('#current-list');
  c.innerHTML='';
  const all = [...db.channels.map(ch=>'Canal: '+ch.name), ...db.films.map(f=>'Filme: '+f.title)];
  all.forEach(text=>{
    const div = document.createElement('div'); div.textContent = text; div.className='small'; c.appendChild(div);
  });
}
renderCurrentList();

// Import/export
$('#export-db').addEventListener('click', ()=>{
  const blob = new Blob([JSON.stringify(db, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download='meuflix_db.json'; a.click();
  URL.revokeObjectURL(url);
});

$('#import-file').addEventListener('change', (e)=>{
  const file = e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = ()=> {
    try{
      const data = JSON.parse(reader.result);
      if(data.channels && data.films){
        db = data; saveDB(); alert('Banco importado com sucesso');
      } else alert('Arquivo inválido');
    }catch(err){ alert('Erro lendo o arquivo') }
  };
  reader.readAsText(file);
});

// initial render
renderCards('films');
